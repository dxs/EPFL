#include <stdlib.h>
#include <stdio.h>
#include "liste.h"
/*-----------------------------------------------*/
ELEMENT * liste_ajouter ( ELEMENT ** p_tete )
{

}

/*-----------------------------------------------*/
void liste_retirer ( ELEMENT ** p_tete, ELEMENT *el )
{

}

void vider_liste ( ELEMENT ** p_liste )
{
  /* Retire un à un les elements en tete de la liste  */

} 


/*-----------------------------------------------*/
void liste_afficher ( ELEMENT *tete )
{

}
