#!/bin/bash

# declare a variable
text="Hello World"

# print it on the screen
echo $text

