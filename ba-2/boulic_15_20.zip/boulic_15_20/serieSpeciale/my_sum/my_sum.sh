#!/bin/bash

let result=$1+$2
echo "Name of the program is $0"
echo "Sum of the input is $result."

