#!/bin/bash

for a in 1 2 3 4 5
do  
        echo "Next number is $a"
done

