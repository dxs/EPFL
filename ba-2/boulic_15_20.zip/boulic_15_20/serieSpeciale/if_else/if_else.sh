#!/bin/bash

# declare a variable called NUM
NUM=5

if [ $NUM -le 6 ]; then
        echo "NUM is less than or equal to 6"
else
        echo "NUM is greater than 6"
fi

