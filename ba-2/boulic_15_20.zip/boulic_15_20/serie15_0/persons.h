#ifndef PERSONS_H
#define PERSONS_H


int getBob();
int getAnne();
void personEat(int person, int fruit);

#endif

