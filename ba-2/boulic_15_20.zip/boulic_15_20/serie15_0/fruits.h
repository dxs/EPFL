#ifndef FRUITS_H
#define FRUITS_H

int getApple();
int getBanana();
void eatFruit(int fruit);

#endif
