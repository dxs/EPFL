       contenu du fichier DEMO 17.zip

Un fichier source à compléter pour votre projet : projet17.c

Ce nom de fichier vous permet d’utiliser le fichier script 
test_projet17_inter.sh pour tester votre programme pour le 
premier rendu. Ce nom devra être changé avec le numéro de SCIPER 
pour le téléchargement sur moodle comme expliqué en 4.1 et 4.2.

Deux exécutables de démo compilés et fonctionnant sur la machine virtuelle du cours. C’est le moyen le plus efficace de vérifier 
un aspect de la donnée qui ne vous semble pas clair. Exécutez 
d’abord le programme de démo car c’est lui qui fait foi pour les rendus :
- inter_demo17.x vérification des données (rendu intermédiaire)
- final_demo17.x est le programme de démo complet

12 fichiers tests :
- De test1.txt à test6.txt pour le rendu intermédiaire (inter_demo17.x )
- De test1.txt à test12.txt pour le rendu final (final_demo17.x )

Un fichier script : test_projet17_inter.sh 
Il s’agit d’un fichier texte écrit dans le langage de commande 
du système d’exploitation. Avec ces commandes il est possible
d’automatiser les tests comme vous pouvez le constater en l’ouvrant
dans geany. Si vous voulez utiliser le script il ne faut pas modifier
pas la structure du dossier ni les noms de fichier. Le script s’exécute comme un programme s’il a le droit en exécution ( ajouter 
au besoin ) :

./test_projet17_inter.sh
